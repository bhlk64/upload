package com.puyet.hack;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.provider.*;
import android.view.*;
import android.widget.*;
import android.util.*;
import android.net.*;
import android.net.wifi.*;
import android.text.format.*;
import java.io.*;
import java.net.*;

public class FloatingButton extends Service {
    private WindowManager windowManager;
    private View overlay;
    private Button run;
    private WindowManager.LayoutParams params;
    private Socket socket;
    private OutputStream cmd;
    private boolean isPermission = false;
    private boolean isOverlayed = false;
    private boolean isSocketReady = false;
    private String ip;

    @Override
    public void onCreate() {
        super.onCreate();

	createNotificationChannel();

	Notification notification = new Notification.Builder(this, "floating_service")
            .setContentTitle("Floating Button")
            .setContentText("Service is running")
            .build();

	startForeground(1, notification); // đây là bước bắt buộ
	
	ip = getWifiIpAddress(this);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        getPermission();
        initParams();
        initSocket();
        showOverlay();
    }

    private void getPermission() {
        isPermission = Settings.canDrawOverlays(this);
    }

    private void initParams() {
        params = new WindowManager.LayoutParams(
	    WindowManager.LayoutParams.WRAP_CONTENT,
	    WindowManager.LayoutParams.WRAP_CONTENT,
	    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
	    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
	    PixelFormat.TRANSLUCENT
        );
        params.x = 0;
        params.y = 100;
    }

    private volatile boolean socketStarted = false;

    private void initSocket() {
	if (socketStarted) return; // tránh start nhiều thread
	socketStarted = true;

	new Thread(new Runnable() {
		@Override
		public void run() {
		    try {
			socket = new Socket("127.0.0.1", 6666);
			cmd = socket.getOutputStream();
			isSocketReady = true;

			if (overlay != null && run != null) {
			    new Handler(Looper.getMainLooper()).post(new Runnable() {
				    @Override
				    public void run() {
					run.setEnabled(true);
				    }
				});
			}
		    } catch (Exception e) {
			e.printStackTrace();
		    }
		}
	    }).start();
    }

    private void showOverlay() {
        if (!isPermission || isOverlayed) return;

        new Handler(Looper.getMainLooper()).post(new Runnable() {
		@Override
		public void run() {
		    overlay = LayoutInflater.from(FloatingButton.this).inflate(R.layout.button, null);
		    if (overlay == null) return;

		    windowManager.addView(overlay, params);
		    isOverlayed = true;

		    run = overlay.findViewById(R.id.run);
		    run.setEnabled(isSocketReady); // Disable nếu socket chưa sẵn sàng

		    // Drag overlay
		    run.setOnTouchListener(new View.OnTouchListener() {
			    private int initialX, initialY;
			    private float initialTouchX, initialTouchY;

			    @Override
			    public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()) {
				    case MotionEvent.ACTION_DOWN:
					initialX = params.x;
					initialY = params.y;
					initialTouchX = event.getRawX();
					initialTouchY = event.getRawY();
					return true;
				    case MotionEvent.ACTION_MOVE:
					params.x = initialX + (int)(event.getRawX() - initialTouchX);
					params.y = initialY + (int)(event.getRawY() - initialTouchY);
					windowManager.updateViewLayout(overlay, params);
					return true;
				}
				return false;
			    }
			});
                    
		    // Click button
		    run.setOnClickListener(new View.OnClickListener() {
			    @Override
			    public void onClick(View v) {
				new Thread(new Runnable() {
					@Override
					public void run() {
					    try {
						if (socket == null || socket.isClosed()) {
						    try {
							socket = new Socket(ip, 6679); // reconnect
							cmd = socket.getOutputStream();
						    } catch (Exception e) {
							e.printStackTrace();
							return; // fail, không crash
						    }
						}
						cmd.write("ENTER\n".getBytes());
						cmd.flush();
						// debug log
						Log.d("FloatingButton", "ENTER sent!");
					    } catch (Exception e) {
						e.printStackTrace();
					    }
					}
				    }).start();
			    }
			});
		}
	    });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (overlay != null) {
            new Handler(Looper.getMainLooper()).post(new Runnable() {
		    @Override
		    public void run() {
			try {
			    windowManager.removeView(overlay);
			} catch (Exception ignored) {}
			overlay = null;
			isOverlayed = false;
		    }
		});
        }

        new Thread(new Runnable() {
		@Override
		public void run() {
		    try {
			if (cmd != null) cmd.close();
			if (socket != null) socket.close();
		    } catch (Exception e) {
			e.printStackTrace();
		    }
		}
	    }).start();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public static String getWifiIpAddress(Context ctx) {
	try {
	    WifiManager wm = (WifiManager) ctx.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
	    if (wm == null) return null;
	    WifiInfo info = wm.getConnectionInfo();
	    int ipInt = info.getIpAddress(); // little-endian
	    if (ipInt == 0) return null;
	    return Formatter.formatIpAddress(ipInt); // returns "192.168.x.y"
	} catch (Exception e) {
	    e.printStackTrace();
	    return null;
	}
    }
    private void createNotificationChannel() {
	if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
	    NotificationChannel channel = new NotificationChannel(
		"floating_service",
		"Floating Button Service",
		NotificationManager.IMPORTANCE_LOW
	    );
	    NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
	    if (manager != null) manager.createNotificationChannel(channel);
	}
    }
}
