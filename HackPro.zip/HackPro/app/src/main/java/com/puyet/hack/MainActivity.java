package com.puyet.hack;

import android.app.*;
import android.os.*;
import org.w3c.dom.*;
import android.widget.*;
import android.provider.*;
import android.view.*;
import android.content.*;
import android.net.*;
import android.graphics.*;
import java.util.zip.*;
import android.text.method.*;
import java.io.*;
import android.view.View.*;
import android.text.*;
import android.util.*;
import android.*;
import android.content.pm.*;

public class MainActivity extends Activity
{
    Button button,submitButton,run,btnHome,btnPackage,btnLog,needStorage,installPip;
    boolean isPermission;
    ImageButton menuButton;
    WindowManager.LayoutParams params = new WindowManager.LayoutParams(
	WindowManager.LayoutParams.WRAP_CONTENT,
	WindowManager.LayoutParams.WRAP_CONTENT,
	WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,  // overlay type
	WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,        // không lấy focus
	PixelFormat.TRANSLUCENT                               // kiểu pixel
    );
    View overlay,menuLayout,homeTab,pipTab;
    WindowManager winman;
    EditText storage,editVar,pipEdit;
    SharedPreferences editsSaves;
    SharedPreferences.Editor edit;
    LinearLayout layoutHome,layoutPip;
    ScrollView layoutLog;
    PyBridge python;
    TextView logcat;
    
    
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
	
	
        super.onCreate(savedInstanceState);
	/*if (getSupportActionBar() != null) {
	    getSupportActionBar().hide();
	}*/
	Log.d("a", "test");
        setContentView(R.layout.main);
        Startup();
	winman = (WindowManager)getSystemService(WINDOW_SERVICE);
	storage.setText(editsSaves.getString("file", null));
	editVar.setText(editsSaves.getString("variable", null));
	Run();
    }
    
    @Override
    protected void onResume() {
	super.onResume();
	Startup();
	Run();
    }
    @Override
    protected void onDestroy() {
	super.onDestroy();
	if (overlay != null) {
	    winman.removeView(overlay);
	    overlay = null;
	}
    }
    public void Run() {
	OnClickListener switchTab = new OnClickListener() {
	    @Override
	    public void onClick(View v) {
		layoutHome.setVisibility(View.GONE);
		layoutPip.setVisibility(View.GONE);
		layoutLog.setVisibility(View.GONE);
		Button current = (Button)v;
		String text = current.getText().toString();
		String textHome = getString(R.string.textHome);
		String textPip = getString(R.string.textPip);
		String textLog = getString(R.string.textLog);
		if (text == textHome) {
		    layoutHome.setVisibility(View.VISIBLE);
		} else if (text == textPip) {
		    layoutPip.setVisibility(View.VISIBLE);
		} else if (text == textLog) {
		    layoutLog.setVisibility(View.VISIBLE);
		}
		  
		
	    }
	};
	btnHome.setOnClickListener(switchTab);
	btnPackage.setOnClickListener(switchTab);
	btnLog.setOnClickListener(switchTab);
	
	button.setVisibility(isPermission ? View.GONE : View.VISIBLE);
	needStorage.setVisibility(isPermission ? View.GONE : View.VISIBLE);

	if (!isPermission || overlay != null) return;
	
	storage.setVisibility(View.VISIBLE);
	submitButton.setVisibility(View.VISIBLE);
	editVar.setVisibility(View.VISIBLE);
	submitButton.setOnClickListener(new OnClickListener() {
	    @Override
	    public void onClick(View view) {
	        String location = storage.getText().toString();
	        String Var = editVar.getText().toString();
		
		edit.putString("file", location);
		edit.putString("variable", Var);
		edit.apply();
	    }
	});
	PyBridge.setLogView(logcat, this);
	initPy();
	
	menuButton.setOnClickListener(new View.OnClickListener() {
		@Override
		public void onClick(View v) {
		    if (menuLayout.getVisibility() == View.GONE) {
			menuLayout.setVisibility(View.VISIBLE);
		    } else {
			menuLayout.setVisibility(View.GONE);
		    }
		}
	    });
	
	

/*	Intent intent = new Intent(this, FloatingButton.class);
	// START SERVICE ASYNC, không block UI
	if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
	    startForegroundService(intent); // Android 8+
	} else {
	    startService(intent);
	}*/
    }

    
    public void Startup() {
	button = findViewById(R.id.permission);
	storage = findViewById(R.id.storage);
	submitButton=findViewById(R.id.submit);
	editVar = findViewById(R.id.varFile);
	editsSaves = getSharedPreferences("configs", MODE_PRIVATE);
	edit = editsSaves.edit();
	menuButton = findViewById(R.id.menuButton);
	menuLayout = findViewById(R.id.menuLayout);
	btnHome = findViewById(R.id.btnHome);
	btnPackage = findViewById(R.id.btnPackage);
	btnLog = findViewById(R.id.btnLog);
	layoutHome = findViewById(R.id.tabHome);
	layoutPip = findViewById(R.id.tabPackage);
	layoutLog = findViewById(R.id.tabLog);
	needStorage = findViewById(R.id.external);
	pipEdit = findViewById(R.id.pipInstall);
	installPip = findViewById(R.id.installPip);
	logcat = findViewById(R.id.logText);
	logcat.setMovementMethod(new ScrollingMovementMethod());
	python = new PyBridge();
	
	isPermission = Settings.canDrawOverlays(this)&&(checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED);
	
	button.setOnClickListener(new OnClickListener() {
		@Override
		public void onClick(View v){
		    Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
		    startActivity(intent);
		}
	    });
	installPip.setOnClickListener(new OnClickListener() {
		@Override
		public void onClick(View v) {
		    // Lấy giá trị ở main thread
		    final String cmd = pipEdit.getText().toString().trim();
		    if (cmd.isEmpty()) return;
		    if (!cmd.contains("pip")) return; // chỉ chạy lệnh pip
		    
		    try {
		        python.nativeRunPython(cmd); // cmd local, không chạm UI
		    } catch (Exception e) {
		        PyBridge.log("[PY ERROR] " + e.getMessage());
		    }
		}
	    });
	needStorage.setOnClickListener(new OnClickListener() {
	    @Override
	    public void onClick(View v) {
		requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1001);
	    }
	});
    }
    public void initPy() {
        String pythonHome = "/storage/emulated/0/python3.12";   // nơi m copy Python
        String pythonPath = pythonHome + "/lib";
        PyBridge.initPython(pythonHome, pythonPath);
    }
}

