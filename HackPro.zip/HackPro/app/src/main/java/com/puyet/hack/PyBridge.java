package com.puyet.hack;

import android.util.Log;
import android.widget.TextView;
import android.app.Activity;

import java.io.OutputStream;
import java.io.PrintStream;

public class PyBridge {
    static {
        System.loadLibrary("android-support");
        System.loadLibrary("python3.12");
        System.loadLibrary("nativebridge"); // tên .so của m
    }

    private static final String TAG = "PyBridge";
    private static TextView logView;
    private static Activity context;

    // Native functions
    public static native int nativeInit(String pythonHome, String pythonPath);
    public static native void nativeRunPython(String code);

    // ===== Logging utilities =====

    public static void setLogView(TextView view, Activity ctx) {
        logView = view;
        context = ctx;
        redirectSystemStreams();
    }

    public static void log(final String msg) {
        Log.d(TAG, msg);
        if (logView != null && context != null) {
            context.runOnUiThread(new Runnable () {
                @Override
                public void run() {
                    logView.append(msg + "\n");
                }
            });
        }
    }

    // Redirect stdout / stderr to TextView
    private static void redirectSystemStreams() {
        PrintStream logStream = new PrintStream(new OutputStream() {
            @Override
            public void write(int b) {
                updateTextView(String.valueOf((char) b));
            }
        });
        System.setOut(logStream);
        System.setErr(logStream);
    }

    private static void updateTextView(final String text) {
        if (logView != null && context != null) {
            context.runOnUiThread(new Runnable () {
                @Override
                public void run() {
                    logView.append(text);
                    int scrollAmount = logView.getLayout() != null
                            ? logView.getLayout().getLineTop(logView.getLineCount()) - logView.getHeight()
                            : 0;
                    if (scrollAmount > 0)
                        logView.scrollTo(0, scrollAmount);
                    else
                        logView.scrollTo(0, 0);
                }
            });
        }
    }

    // ===== Python Control =====

    public static void initPython(final String pythonHome, final String pythonPath) {
        new Thread(new Runnable () {
            @Override
            public void run() {
                log("[PyBridge] Initializing Python...");
                int ok = nativeInit(pythonHome, pythonPath);
                if (ok == 1)
                    log("[PyBridge] ✅ Python initialized!");
                else
                    log("[PyBridge] ❌ Python init failed.");
            }
        }).start();
    }

    public static void runPython(final String code) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                log("[PyBridge] ▶ Running code...");
                nativeRunPython(code);
                log("[PyBridge] 🧩 Code done.");
            }
        }).start();
    }
}
